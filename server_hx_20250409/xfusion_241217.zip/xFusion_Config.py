# HW info
expected_memory_counts = 16
expected_memory_locators = ['DIMM000', 'DIMM010', 'DIMM020', 'DIMM030', 'DIMM040']
expected_memory_locators += ['DIMM050', 'DIMM060', 'DIMM070', 'DIMM100', 'DIMM110']
expected_memory_locators += ['DIMM120', 'DIMM130', 'DIMM140', 'DIMM150', 'DIMM160', 'DIMM170']
expected_memory_brand_check = True
expected_memory_size_check = True
expected_memory_size = [32768]
expected_memory_speed = 3200
#
expected_cpu_model = 'xxxxxxxxxxxxxx'
expected_cpu_counts = 2
#
expected_pci_installed_slot = []
expected_pci_counts = 2
#
expected_psu_counts = 2
expected_psu_watts = 900
expected_psu_Model = 'PAC900S12-B2'
#
#
expected_hdd_counts = 1
expected_hdd_size   = 146
expected_hdd_type   = 'nvme'
